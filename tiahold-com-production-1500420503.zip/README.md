# tiahold.com

```bash
git clone https://github.com/dhhenderson/tiahold.com.git
cd tiahold.com
virtualenv ENV
. ENV/bin/activate
pip install -r requirements.txt
aws configure
zappa deploy
```
