import boto3

from boto.dynamodb2.fields import HashKey
from boto.dynamodb2.table import Table

from flask import Flask, render_template, json
from flask_bootstrap import Bootstrap
from flask_dynamo import Dynamo

import requests

app = Flask(__name__)
app.config.from_object('default_settings')
app.config.from_envvar('TIAHOLD_SETTINGS', silent=True)
#print(app.config['DEBUG'])

Bootstrap(app)

# initialize db
app.config['DYNAMO_TABLES'] = [
    Table('favs', schema=[HashKey('name')]),
]
dynamo = Dynamo(app)

# timestamp ajax callback
@app.route('/_get_timestamp')
def get_timestamp():
    try:
        r = requests.get(app.config['TIMESTAMP_URL'], timeout=2)
        data = json.loads(r.text)
        app.logger.info(r.text)
        return data['timestamp']
    except requests.exceptions.RequestException as e:
        app.logger.error(e)
        return 'Timestamp unavailable'

@app.route('/')
@app.route('/index.html')
@app.route('/index.htm')
def index():
    return render_template('index.html')

@app.route('/favs')
def favs():
#    print(app.config['DYNAMO_ENABLE_LOCAL'])
    dynamodb = boto3.resource('dynamodb') #, endpoint_url='http://localhost:8000')
    table = dynamodb.Table('favs')
    response = table.scan()
    favs = response['Items']
    print(favs)

    return render_template('favs.html', favs=favs)
#    favs = dynamo.tables['favs'].scan()
#    return render_template('favs.html', favs=favs)
'''
    favs = [
        {'name': 'bloom', 'url': 'https://www.bloomberg.com/'},
        {'name': 'bbc', 'url': 'http://www.bbc.com/news'},
        {'name': 'cnbc', 'url': 'http://www.cnbc.com/'},
        {'name': 'drudge', 'url': 'http://www.drudgereport.com'},
        {'name': 'wp', 'url': 'https://www.washingtonpost.com'},
        {'name': 'nyt', 'url': 'https://www.nytimes.com/'}
    ]
'''

@app.cli.command('createdb')
def createdb_command():
    with app.app_context():
        dynamo.create_all()

@app.cli.command('insertdata')
def insertdata_command():
    dynamo.tables['favs'].put_item(data={
        'name': 'bloom',
        'url': 'https://www.bloomberg.com',
    })

    favs = dynamo.tables['favs'].scan()
    for fav in favs:
        print fav['name']
        print fav['url']

# We only need this for local development.
if __name__ == '__main__':
    app.run()
